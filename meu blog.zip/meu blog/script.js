document.getElementById("menu-button").addEventListener("click", function() {
   const nav = document.querySelector("nav");
   nav.style.display = nav.style.display === "block" ? "none" : "block";
});

